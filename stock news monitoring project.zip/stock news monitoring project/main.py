import requests
import os
#from twilio.rest import Client
#from twilio.http.http_client import TwilioHttpClient



STOCK = "TSLA"
COMPANY_NAME = "Tesla Inc"
STOCK_ENDPOINT = "https://www.alphavantage.co/query"
NEWS_ENDPOINT = 0
news_api_key = "2d170390c37b4efd915ced3dd0af399e"
stocks_api_key = "MPA85DQPJ4DSUCH2"


stock_params = {"function":"TIME_SERIES_DAILY_ADJUSTED", "symbol": STOCK, "apikey": stocks_api_key}
response = requests.get(STOCK_ENDPOINT, params=stock_params )
#print(response.json())

data = response.json()["Time Series (Daily)"]
data_list = [value for (key,value) in data.items()]
#print(data_list)
yesterday_data = data_list[0]
print(yesterday_data)
yesterday_closing_price = yesterday_data["4. close"]
print(yesterday_closing_price)

