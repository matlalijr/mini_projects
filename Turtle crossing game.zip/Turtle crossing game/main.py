import time
import random
from turtle import Screen
from player import Player
from car_manager import CarManager
from scoreboard import Scoreboard

screen = Screen()
screen.setup(width=600, height=600)
screen.tracer(0)

turt = Player()
car_list = []
score = Scoreboard()

screen.listen()
screen.onkey(turt.up, "Up")
game_is_on = True
time_speed = 0.5
while game_is_on:
    time.sleep(time_speed)
    screen.update()
    cars = CarManager()
    car_list.append(cars)
    cars.move()
    for car in car_list:
        car.move()
    #detect collision with car
        if car.distance(turt) < 20:
            score.game_over()
            game_is_on = False
    if turt.ycor()>290:
        score.update_level()
        turt.reset_game()
        time_speed*=0.9









    #detect finish line
    # if turt.ycor()>280:
        # print("You win")
        # break





screen.exitonclick()