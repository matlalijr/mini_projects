from tkinter import *  # this will import only the classes and constants
from tkinter import messagebox  # message box is neither a class nor a constant
import random
# import pyperclip
import json

# ---------------------------- PASSWORD GENERATOR ------------------------------- #
letters = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v',
           'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R',
           'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
numbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
symbols = ['!', '#', '$', '%', '&', '(', ')', '*', '+']

nr_letters = random.randint(8, 10)
nr_symbols = random.randint(2, 4)
nr_numbers = random.randint(2, 4)

password_list = []

password_list += [random.choice(letters) for char in range(nr_letters)]

password_list += [random.choice(symbols) for char in range(nr_symbols)]

password_list += [random.choice(numbers) for char in range(nr_numbers)]

random.shuffle(password_list)

password = "".join(password_list)

print(f"Your password is: {password}")


def create_password():
    global password
    pass_entry.insert(0, password)


# ---------------------------- SAVE PASSWORD ------------------------------- #
def save():
    """This function will save the data into the file "data.txt".
    Note that the messagebox returns a boolean value!Clicking "OK" means choosing True! """

    website = website_entry.get()
    email = email_entry.get()
    passcode = pass_entry.get()
    new_data = {website: {
        "email": email,
        "password": passcode

    }
    }

    if len(website_entry.get()) == 0 or len(pass_entry.get()) == 0:
        messagebox.showerror(title="Oops", message="Please do not leave any fields empty!")

    else:
        try:
            with open("data.json", "r") as datafile:
                # data = json.load(datafile) # load data up and store it in a dictionary,will cause
                # an error if there is no data inside the json file to load so rather use the code below:

                data = json.loads(datafile.read())

                # print(data)

        # -----------json.dump(dump what?,into what?,indent by how much?)-------- #
        except FileNotFoundError:
            with open("data.json", "w") as datafile:
                json.dump(new_data, datafile, indent=4)

        else:
            data.update(new_data)  # update the dictionary,data, to store more data, the "new_data"
            with open("data.json", "w") as datafile:
                json.dump(data, datafile, indent=4)  # actually write the "data" into the now updated "data.json" file
        finally:
            website_entry.delete(0, 'end')
            pass_entry.delete(0, 'end')


# ---------------------------- UI SETUP ------------------------------- #
# CREATING THE WINDOW

window = Tk()
window.title("Password Manager")
window.config(pady=20, padx=20)
# CREATING THE CANVAS

canvas = Canvas(width=200, height=200)
pass_logo = PhotoImage(file="logo.png")
canvas.create_image(100, 100, image=pass_logo)
canvas.grid(row=0, column=1)

# CREATING LABELS
website_label = Label(text="Website:")
website_label.grid(row=1, column=0)
email_label = Label(text="Email/Username:")
email_label.grid(row=2, column=0)
pass_label = Label(text="Password:")
pass_label.grid(row=3, column=0)

# ENTRIES
website_entry = Entry(width=30)
website_entry.grid(row=1, column=1, columnspan=2, sticky=W)
website_entry.focus()
email_entry = Entry(width=36)
email_entry.grid(row=2, column=1, columnspan=2, sticky=W)
email_entry.insert(0, "cmseutloali@gmail.com")
pass_entry = Entry(width=17)
pass_entry.grid(row=3, column=1, sticky=W)

# BUTTONS
add_button = Button(text="Add", width=30, command=save)
add_button.grid(row=4, column=1, columnspan=2, sticky=W)

password_button = Button(text="Generate Password", command=create_password)
password_button.grid(row=3, column=1, columnspan=2, sticky=E)


# ------------------------------REVEAL PASSWORD------------------------- #


def show_details():
    global website_entry
    try:
        with open("data.json", "r") as datafile:
            data = json.loads(datafile.read())
            messagebox.askokcancel(title=website_entry.get(),
                                   message=f"Email: {data[website_entry.get()]['email']}\nPassword: {data[website_entry.get()]['password']}")
    except:
        messagebox.askokcancel(title=website_entry.get(), message="The specified website was not found")


search_button = Button(text="Search", width=10, command=show_details)
search_button.grid(row=1, column=2, sticky=E)

# pyperclip.copy(password)

window.mainloop()
