from question_model import Question
from data import question_data
from quiz_brain import QuizBrain

question_bank = []


def quiz():
    for i in range(len(question_data)):
        question_text= question_data[i]["text"]
        question_answer = question_data[i]["answer"]
        question_object = Question(question_text,question_answer)
        question_bank.append(question_object)

quiz()

quiz_object = QuizBrain(question_bank)
quiz_object.next_question()

next = True
while next:
    if quiz_object.question_number == len(quiz_object.question_list) :
        next = False
        print("You have completed the quiz")
        print(f"Your final score is: {quiz_object.score}/{quiz_object.question_number}")
    else:
        quiz_object.still_has_questions()


